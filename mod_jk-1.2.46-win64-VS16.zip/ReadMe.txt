16 June 2019

                                       Apache Lounge Distribution

                                   mod_jk 1.2.46  for Apache 2.4 Win64 VS16


# Original source by: http://tomcat.apache.org
# Binary by: Steffen
# Mail: info@apachelounge.com
# Home: http://www.apachelounge.com/

# Announcement and Change log : www.apachelounge.com/viewtopic.php?p=31499

Build with Visual Studio� 2019 (VS16) 
--------------------------------------------
Be sure you have installed the Visual C++ Redistributable for Visual Studio 2015-2019.
Download and install, if you not have it already, see:

 http://www.apachelounge.com/download/

Enjoy,

Steffen
